<?php
    
namespace WorldGuardian;

use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\Listener;
use pocketmine\command\CommandExecutor;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\command\CommandSender;
use pocketmine\command\Command;
use pocketmine\Player;
use pocketmine\plugin\PluginBase;
use pocketmine\item\Item;
use pocketmine\utils\Config;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageByEntity;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\utils\TextFormat;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\player\PlayerDropItemEvent;
class WorldGuardian extends PluginBase implements CommandExecutor, Listener {
    private $db, $pos1 = array(), $pos2 = array();
    private $config;
    private $xgroup;
    private $g_var;
    public function pct_msg($mes)
    {
        $mes = str_replace("&1", "§1", $mes);
        $mes = str_replace("&2", "§2", $mes);
        $mes = str_replace("&3", "§3", $mes);
        $mes = str_replace("&4", "§4", $mes);
        $mes = str_replace("&5", "§5", $mes);
        $mes = str_replace("&6", "§6", $mes);
        $mes = str_replace("&7", "§7", $mes);
        $mes = str_replace("&8", "§8", $mes);
        $mes = str_replace("&9", "§9", $mes);
        $mes = str_replace("&a", "§a", $mes);
        $mes = str_replace("&b", "§b", $mes);
        $mes = str_replace("&c", "§c", $mes);
        $mes = str_replace("&d", "§d", $mes);
        $mes = str_replace("&e", "§e", $mes);
        $mes = str_replace("&f", "§f", $mes);
        return $mes;
    }
    public function onBlockBreak(BlockBreakEvent $event)
    {
        $player   = $event->getPlayer();
        $x        = round($event->getBlock()->getX());
        $y        = round($event->getBlock()->getY());
        $z        = round($event->getBlock()->getZ());
        $level    = $event->getBlock()->getLevel()->getName();
        $username = strtolower($event->getPlayer()->getName());
        if ($event->getItem()->getID() == 263) {
            $this->pos1[$username] = array(
                $x,
                $y,
                $z,
                $level
            );
            $event->getPlayer()->sendMessage(TextFormat::LIGHT_PURPLE . 'The first point is assigned to (' . $x . ', ' . $y . ', ' . $z . ')');
            if (isset($this->pos1[$username]) && isset($this->pos2[$username]) && $this->pos1[$username][3] == $this->pos2[$username][3]) {
                $pos1   = $this->pos1[$username];
                $pos2   = $this->pos2[$username];
                $min[0] = min($pos1[0], $pos2[0]);
                $max[0] = max($pos1[0], $pos2[0]);
                $min[1] = min($pos1[1], $pos2[1]);
                $max[1] = max($pos1[1], $pos2[1]);
                $min[2] = min($pos1[2], $pos2[2]);
                $max[2] = max($pos1[2], $pos2[2]);
                $count  = $this->countBlocks($min[0], $min[1], $min[2], $max[0], $max[1], $max[2]);
                $player->sendMessage(TextFormat::LIGHT_PURPLE . "Selected $count block (s).");
            }
            $event->setCancelled(true);
        } else {
            $result            = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $member            = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '" . $result['Region'] . "' AND Name = '$username'")->fetchArray(SQLITE3_ASSOC);
            $flag              = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'build' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
            $chest_access_flag = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'chest-access' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
            if ($result !== false && $username != $result['Owner'] && !$event->getPlayer()->isOp() && !$member['count'] && !$flag['count'] and !$event->getPlayer()->hasPermission("worldguardian.breakotherregions") /**/) {
                $event->getPlayer()->sendMessage("§fYou cannot break the blocks in this region.");
                $event->setCancelled(true);
            }
        }
    }
    public function onEntityDamageByEntity(EntityDamageEvent $event)
    {
        $entity = $event->getEntity();
        if ($event instanceof EntityDamageByEntityEvent) {
            $damager         = $event->getDamager();
            $leveld          = $damager->getLevel()->getName();
            $xd              = round($damager->getX());
            $yd              = round($damager->getY());
            $zd              = round($damager->getZ());
            $resultd_check   = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $xd AND $xd <= Pos2X) AND (Pos1Y <= $yd AND $yd <= Pos2Y) AND (Pos1Z <= $zd AND $zd <= Pos2Z) AND Level = '" . $leveld . "';")->fetchArray(SQLITE3_ASSOC);
            $resultd         = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $xd AND $xd <= Pos2X) AND (Pos1Y <= $yd AND $yd <= Pos2Y) AND (Pos1Z <= $zd AND $zd <= Pos2Z) AND Level = '" . $leveld . "';")->fetchArray(SQLITE3_ASSOC);
            $pvpd_flag       = $this->db->query("SELECT * FROM FLAGS WHERE Region = '" . $resultd['Region'] . "' AND Flag = 'pvp'")->fetchArray(SQLITE3_ASSOC);
            $pvpd_flag_check = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $resultd['Region'] . "' AND Flag = 'pvp'")->fetchArray(SQLITE3_ASSOC);
            $levele          = $entity->getLevel()->getName();
            $xe              = round($entity->getX());
            $ye              = round($entity->getY());
            $ze              = round($entity->getZ());
            $resulte_check   = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $xe AND $xe <= Pos2X) AND (Pos1Y <= $ye AND $ye <= Pos2Y) AND (Pos1Z <= $ze AND $ze <= Pos2Z) AND Level = '" . $levele . "';")->fetchArray(SQLITE3_ASSOC);
            $resulte         = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $xe AND $xe <= Pos2X) AND (Pos1Y <= $ye AND $ye <= Pos2Y) AND (Pos1Z <= $ze AND $ze <= Pos2Z) AND Level = '" . $levele . "';")->fetchArray(SQLITE3_ASSOC);
            $pvpe_flag       = $this->db->query("SELECT * FROM FLAGS WHERE Region = '" . $resulte['Region'] . "' AND Flag = 'pvp'")->fetchArray(SQLITE3_ASSOC);
            $pvpe_flag_check = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $resulte['Region'] . "' AND Flag = 'pvp'")->fetchArray(SQLITE3_ASSOC);
            if ($entity instanceof Player && $damager instanceof Player) {
                if (($resultd_check['count'] && $pvpd_flag_check['count']) || ($resulte_check['count'] && $pvpe_flag_check['count'])) {
                    if ($pvpd_flag['Value'] == "deny" && $pvpe_flag['Value'] != "deny") {
                        $event->setCancelled(true);
                        $damager->sendMessage("You can't fight in this region.");
                    }
                    if ($pvpd_flag['Value'] == "deny" && $pvpe_flag['Value'] == "deny") {
                        $event->setCancelled(true);
                        $damager->sendMessage("You can't fight in this region.");
                    }
                    if ($pvpd_flag['Value'] != "deny" && $pvpe_flag['Value'] == "deny") {
                        $event->setCancelled(true);
                        $damager->sendMessage("You can't fight in this region.");
                    }
                }
            }
        }
    }
    public function onEntityDamage(EntityDamageEvent $event)
    {
        $entity = $event->getEntity();
        if ($event instanceof EntityDamageEvent) {
            if ($entity instanceof Player) {
                $x      = round($entity->getX());
                $y      = round($entity->getY());
                $z      = round($entity->getZ());
                $level  = $entity->getLevel()->getName();
                $player = $entity->getPlayer();
                $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
                $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'invincible' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if ($count['count'] && $flag['count']) {
                    $event->setCancelled(true);
                }
            }
        }
    }
    public function onPlayerChat(PlayerChatEvent $event)
    {
        $player   = $event->getPlayer();
        $x        = round($player->getX());
        $y        = round($player->getY());
        $z        = round($player->getZ());
        $level    = $player->getLevel()->getName();
        $username = strtolower($player->getName());
        $result   = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
        $count    = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
        $flag     = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'send-chat' AND Value = 'deny'")->fetchArray(SQLITE3_ASSOC);
        if ($count['count'] && $flag['count'] && !$player->isOp()) {
            $player->sendMessage("§6>§f You do not have permission to use chat in this region");
            $event->setCancelled(true);
        }
    }
    public function onPlayerDropItem(PlayerDropItemEvent $event)
    {
        $player   = $event->getPlayer();
        $x        = round($player->getX());
        $y        = round($player->getY());
        $z        = round($player->getZ());
        $level    = $player->getLevel()->getName();
        $username = strtolower($player->getName());
        $result   = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
        $flag     = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'item-drop' AND Value = 'deny'")->fetchArray(SQLITE3_ASSOC);
        if ($flag['count']) {
            $player->sendMessage("You can drop item in this region.");
            $event->setCancelled(true);
        }
    }
    public function onBlockPlace(BlockPlaceEvent $event)
    {
        $x        = round($event->getBlock()->getX());
        $y        = round($event->getBlock()->getY());
        $z        = round($event->getBlock()->getZ());
        $level    = $event->getBlock()->getLevel()->getName();
        $username = strtolower($event->getPlayer()->getName());
        $result   = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
        $member   = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '" . $result['Region'] . "' AND Name = '$username'")->fetchArray(SQLITE3_ASSOC);
        $flag     = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'build' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
        if ($result !== false and $username != $result['Owner'] and !$event->getPlayer()->isOp() and !$member['count'] and !$flag['count'] and !$event->getPlayer()->hasPermission("worldguardian.breakotherregions") /**/) {
            $event->getPlayer()->sendMessage("You cannot place blocks in this region.");
            $event->setCancelled(true);
        }
    }
    public function onInteract(PlayerInteractEvent $event)
    {
        $player   = $event->getPlayer();
        $block    = $event->getBlock();
        $x        = round($event->getBlock()->getX());
        $y        = round($event->getBlock()->getY());
        $z        = round($event->getBlock()->getZ());
        $level    = $event->getBlock()->getLevel()->getName();
        $username = strtolower($event->getPlayer()->getName());
        if ($event->getItem()->getID() == 263) {
            $this->pos2[$username] = array(
                $x,
                $y,
                $z,
                $level
            );
            $event->getPlayer()->sendMessage(TextFormat::LIGHT_PURPLE . '§6>§f The second point is set to§c: (' . $x . ', ' . $y . ', ' . $z . ')');
            if (isset($this->pos1[$username]) && isset($this->pos2[$username]) && $this->pos1[$username][3] == $this->pos2[$username][3]) {
                $pos1   = $this->pos1[$username];
                $pos2   = $this->pos2[$username];
                $min[0] = min($pos1[0], $pos2[0]);
                $max[0] = max($pos1[0], $pos2[0]);
                $min[1] = min($pos1[1], $pos2[1]);
                $max[1] = max($pos1[1], $pos2[1]);
                $min[2] = min($pos1[2], $pos2[2]);
                $max[2] = max($pos1[2], $pos2[2]);
                $count  = $this->countBlocks($min[0], $min[1], $min[2], $max[0], $max[1], $max[2]);
                $player->sendMessage("§6>§f Selected $count block");
            }
            $event->setCancelled(true);
        }
        if ($event->getBlock()->getID() == 54) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'chest-access' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp() && !$event->getPlayer()->hasPermission("worldguardian.chestaccess")) {
                        $event->getPlayer()->sendTip("§e* §cPrivate/Locked §e*");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getItem()->getID() == 290 || $event->getItem()->getID() == 291 || $event->getItem()->getID() == 292 || $event->getItem()->getID() == 293 || $event->getItem()->getID() == 294) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp()) {
                        $event->getPlayer()->sendMessage("§6>§f You can't craft in this region.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getBlock()->getID() == 64 || $event->getBlock()->getID() == 71 || $event->getBlock()->getID() == 324 || $event->getBlock()->getID() == 330) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'use' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp() and !$event->getPlayer()->hasPermission("worldguardian.breakotherregions")) {
                        $event->getPlayer()->sendMessage("§6>§f You can't open doors in this region.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getBlock()->getID() == 61 || $event->getBlock()->getID() == 62) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'use' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp() and !$event->getPlayer()->hasPermission("worldguardian.breakotherregions")) {
                        $event->getPlayer()->sendMessage("§6>§f You can't use the furnace in this region.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getItem()->getID() == 280) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $count_blocks = $this->countBlocks($result['Pos1X'], $result['Pos1Y'], $result['Pos1Z'], $result['Pos2X'], $result['Pos2Y'], $result['Pos2Z']);
                $flag         = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'info' AND Value = 'deny'")->fetchArray(SQLITE3_ASSOC);
                if (!$flag['count'] || $username == $result['Owner'] || $player->isOp()) {
                    $event->getPlayer()->sendMessage(TextFormat::DARK_GRAY . "===== " . TextFormat::GRAY . "Region " . TextFormat::LIGHT_PURPLE . $result['Region'] . " " . TextFormat::DARK_GRAY . "=====\n" . TextFormat::BLUE . "§6>§3 Owner§c: " . TextFormat::YELLOW . $result['Owner'] . "\n" . TextFormat::BLUE . "§6>§3 Block Count§c: " . TextFormat::YELLOW . $count_blocks . "\n" . TextFormat::BLUE . "§6>§3 Pos 1§c: " . TextFormat::YELLOW . $result['Pos1X'] . ", " . $result['Pos1Y'] . ", " . $result['Pos1Z'] . "\n" . TextFormat::BLUE . "§6>§3 Pos 2§c: " . TextFormat::YELLOW . $result['Pos2X'] . ", " . $result['Pos2Y'] . ", " . $result['Pos2Z']);
                } else {
                    $player->sendMessage("§6>§f Information about this region is hidden.");
                }
                return true;
            } else {
                $event->getPlayer()->sendMessage("§6>§f There are no region here.");
            }
        }
    }
    
    public function getRegionNameAtLocation(Player $player)
    {
        $x = round($player->getX());
        $y = round($player->getY());
        $z = round($player->getZ());
        $level = $player->getLevel()->getName();

        $result = $this->db->query("SELECT Region FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '$level';")->fetchArray(SQLITE3_ASSOC);

        return $result['Region'] ?? null;
    }

    public function onEnable()
    {
        @mkdir($this->getDataFolder());
        $this->g_var  = "45y6thnhn45";
        $this->config = new Config($this->getDataFolder() . "config.yml", Config::YAML);
        if (file_exists($this->getDataFolder() . "xgroups.yml")) {
            $this->xgroup = new Config($this->getDataFolder() . "xgroups.yml", Config::YAML);
        } else {
            $this->xgroup = new Config($this->getDataFolder() . "xgroups.yml", Config::YAML, array(
                'Player' => array(
                    'max_regions_num' => 8,
                    'max_region_count_blocks' => 15000
                ),
                'Vip' => array(
                    'max_regions_num' => 8,
                    'max_region_count_blocks' => 15000
                ),
                'Creative' => array(
                    'max_regions_num' => 8,
                    'max_region_count_blocks' => 15000
                )
            ));
        }
        if (empty($this->config->get("default_xgroup"))) {
            $this->config->set("default_xgroup", "Player");
        }
        $this->config->save();
        $this->xgroup->save();
        $this->loadDB();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }
    public function onTouch(PlayerInteractEvent $event)
    {
        $player   = $event->getPlayer();
        $block    = $event->getBlock();
        $x        = round($event->getBlock()->getX());
        $y        = round($event->getBlock()->getY());
        $z        = round($event->getBlock()->getZ());
        $level    = $event->getBlock()->getLevel()->getName();
        $username = strtolower($event->getPlayer()->getName());
        if ($event->getItem()->getID() == 351 && $event->getItem()->getDamage() == 15) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'bone-meal' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp()) {
                        $event->getPlayer()->sendMessage("§6>§f You can't use bone meal in this region.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getItem()->getID() == 325) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'bucket' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp()) {
                        $event->getPlayer()->sendMessage("§6>§f You can't use buckets in this region.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
        if ($event->getItem()->getID() == 259) {
            $result = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
            if ($count['count']) {
                $member = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username' AND Region = '" . $result['Region'] . "'")->fetchArray(SQLITE3_ASSOC);
                $flag   = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Flag = 'lighter' AND Region = '" . $result['Region'] . "' AND Value = 'allow'")->fetchArray(SQLITE3_ASSOC);
                if (!$member['count'] && !$flag['count'] && $username != $result['Owner']) {
                    if (!$event->getPlayer()->isOp()) {
                        $event->getPlayer()->sendMessage("§6>§f You can't use flint & steel in this area.");
                        $event->setCancelled(true);
                    }
                }
            }
        }
    }
    public function countBlocks($x1, $y1, $z1, $x2, $y2, $z2)
    {
        $count = abs(($x2 - $x1 + 1) * ($y2 - $y1 + 1) * ($z2 - $z1 + 1));
        return $count;
    }
    public function onCommand(CommandSender $sender, Command $cmd, $label, array $args)
    {
        $username = strtolower($sender->getName());
        if (!($sender instanceof Player)) {
            $sender->sendMessage("[ALERT] Using in-game command from console");
            return false;
        }
        $player = $sender;
        switch ($cmd->getName()) {
            case 'member':
                $result       = $this->db->query("SELECT * FROM MEMBERS WHERE Name = '$username'");
                $result_check = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Name = '$username'")->fetchArray(SQLITE3_ASSOC);
                if ($result_check['count']) {
                    $player->sendMessage("§6>§f You are added to the following region§c:");
                    while ($list = $result->fetchArray()) {
                        $player->sendMessage(TextFormat::GRAY . $list['Region']);
                    }
                } else {
                    $player->sendMessage("§6>§f No one has added you to the region");
                }
                break;
            case 'addmember':
                $region = \SQLite3::escapeString(strtolower(array_shift($args)));
                $member = \SQLite3::escapeString(strtolower(array_shift($args)));
                if (!$player->isOp()) {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                } else {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                }
                if (!empty($member) && !empty($region)) {
                    if ($count['count']) {
                        $check = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '$region' AND Name = '$member'")->fetchArray(SQLITE3_ASSOC);
                        if (!$check['count']) {
                            $this->db->query("INSERT INTO MEMBERS (Region, Name) VALUES ('$region','$member')");
                            $player->sendMessage("§6>§f $member has been added to your region");
                        } else {
                            $player->sendMessage("§6>§f $member has been added to your region");
                        }
                    } else {
                        $player->sendMessage("§6>§f Region $region does not exist");
                    }
                } else {
                    $player->sendMessage("§6>§f Usage§c:§3 /addmember§f §7<§fregion§7> <§fplayer§7>");
                }
                break;
            case 'removemember':
                $region = \SQLite3::escapeString(strtolower(array_shift($args)));
                $member = \SQLite3::escapeString(strtolower(array_shift($args)));
                if (!$player->isOp()) {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                } else {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                }
                if (!empty($member) && !empty($region)) {
                    if ($count['count']) {
                        $check = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '$region' AND Name = '$member'")->fetchArray(SQLITE3_ASSOC);
                        if ($check['count']) {
                            $this->db->query("DELETE FROM MEMBERS WHERE Region = '$region' AND Name = '$member'");
                            $player->sendMessage("§6>§f $member has been excluded from your region");
                        } else {
                            $player->sendMessage("§6>§f $member not registered in your region");
                        }
                    } else {
                        $player->sendMessage("§6>§f Region $region does not exist");
                    }
                } else {
                    $player->sendMessage("§6>§f Select the player you want to exclude!");
                }
                break;
            case 'flag':
                $region = \SQLite3::escapeString(strtolower(array_shift($args)));
                $flag   = \SQLite3::escapeString(strtolower(array_shift($args)));
                $value  = \SQLite3::escapeString(strtolower(array_shift($args)));
                if (!$player->isOp()) {
                    $count = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Owner = '$username' AND Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                } else {
                    $count = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                }
                if (!empty($flag) && !empty($value) && !empty($region)) {
                    if ($count['count']) {
                        if ($flag == "pvp" || $flag == "build" || $flag == "chest-access" || $flag == "use" || ($flag == "info" && $player->isOp()) || $flag == "bone-meal" || $flag == "bucket" || $flag == "lighter" || $flag == "send-chat" || $flag == "item-drop" || ($flag == "invincible" && $player->isOp())) {
                            if ($value == "allow" || $value == "deny") {
                                $check_flag = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '$region' AND Flag = '$flag'")->fetchArray(SQLITE3_ASSOC);
                                if ($check_flag['count']) {
                                    $this->db->query("UPDATE FLAGS SET Value = '$value' WHERE Region = '$region' AND Flag = '$flag'");
                                } else {
                                    $this->db->query("INSERT INTO FLAGS (Region, Flag, Value) VALUES ('$region', '$flag', '$value')");
                                }
                                $player->sendMessage(TextFormat::YELLOW . "Value set '$value' for flag '$flag'");
                            } else {
                                $player->sendMessage("§6>§f Values ​​can only §3allow§7 (§fallow§7) §for §3deny§7 (§fprohibit§7)");
                            }
                        } else {
                            $player->sendMessage("§6>§3 Flag available§c:§f pvp, build, chest-access, use, info, bone-meal, bucket, lighter, send-chat, item-drop");
                            if ($player->isOp()) {
                                $player->sendMessage("§6>§3 The flag for administrator§c:§f invincible, info");
                            }
                            if (($flag == "invincible") && !$player->isOp()) {
                                $player->sendMessage("§6>§f You do not have access to this flag.");
                            }
                            if (($flag == "info") && !$player->isOp()) {
                                $player->sendMessage("§6>§f You do not have access to this flag.");
                            }
                        }
                    } else {
                        $player->sendMessage("§6>§f Region $region does not exist");
                    }
                } else {
                    $player->sendMessage("§6>§f Usage§c:§3 /flag §7<§fregion§7> <§fflag§7> <§fvalue§7>");
                }
                break;
            case 'leaveregion':
                $region = \SQLite3::escapeString(strtolower(array_shift($args)));
                if (!empty($region)) {
                    $check = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '$region' AND Name = '$username'")->fetchArray(SQLITE3_ASSOC);
                    if ($check['count']) {
                        $this->db->query("DELETE FROM MEMBERS WHERE Name = '$username' AND Region = '$region'");
                        $player->sendMessage("§6>§f You leaving this region: $region");
                    } else {
                        $player->sendMessage(TextFormat::RED . "You are not registered in the region $region.");
                    }
                } else {
                    $player->sendMessage("§6>§f Select the region you want to leave");
                }
                break;
            case 'wand':
                $id = Item::get(263, 0, 1);
                $player->getInventory()->addItem($id);
                $player->sendMessage(TextFormat::LIGHT_PURPLE . 'Long tap (break the block): first point. Quick tap: second point.');
                break;
            case 'placeadmin':
                $region     = \SQLite3::escapeString(strtolower(array_shift($args)));
                $subcommand = \SQLite3::escapeString(strtolower(array_shift($args)));
                $result     = $this->db->query("SELECT * FROM AREAS WHERE Region = '$subcommand'")->fetchArray(SQLITE3_ASSOC);
                $count      = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$subcommand'")->fetchArray(SQLITE3_ASSOC);
                if ($count['count'] && $region == "info" && !empty($subcommand)) {
                    $count_blocks = $this->countBlocks($result['Pos1X'], $result['Pos1Y'], $result['Pos1Z'], $result['Pos2X'], $result['Pos2Y'], $result['Pos2Z']);
                    $flag         = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '$subcommand' AND Flag = 'info' AND Value = 'deny'")->fetchArray(SQLITE3_ASSOC);
                    if (!$flag['count'] || $username == $result['Owner'] || $player->isOp()) {
                        $player->sendMessage(TextFormat::DARK_GRAY . "===== Region " . TextFormat::GRAY . "$subcommand " . TextFormat::DARK_GRAY . "=====\n" . TextFormat::BLUE . "Owner: " . TextFormat::YELLOW . $result['Owner'] . "\n" . TextFormat::BLUE . "Blocks Count: " . TextFormat::YELLOW . $count_blocks . "\n" . TextFormat::BLUE . "Pos 1: " . TextFormat::YELLOW . $result['Pos1X'] . " " . $result['Pos1Y'] . " " . $result['Pos1Z'] . "\n" . TextFormat::BLUE . "Pos 2: " . TextFormat::YELLOW . $result['Pos2X'] . " " . $result['Pos2Y'] . " " . $result['Pos2Z'] . TextFormat::GRAY);
                    } else {
                        $player->sendMessage(TextFormat::RED . "Information about this region is hidden.");
                    }
                } elseif (!$count['count'] && $region == "info" && !empty($subcommand)) {
                    $player->sendMessage(TextFormat::RED . "The $subcommand region doesn't exist!");
                }
                if (!$player->isOp()) {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region' AND Owner = '$username'")->fetchArray(SQLITE3_ASSOC);
                } else {
                    $result = $this->db->query("SELECT * FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                    $count  = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                }
                if (!empty($region) && $subcommand == "members" && $count['count']) {
                    $members       = $this->db->query("SELECT * FROM MEMBERS WHERE Region = '$region'");
                    $count_members = $this->db->query("SELECT COUNT(*) as count FROM MEMBERS WHERE Region = '$username'")->fetchArray(SQLITE3_ASSOC);
                    $player->sendMessage(TextFormat::DARK_GRAY . "=== " . TextFormat::GRAY . "$region region's members " . TextFormat::DARK_GRAY . "===");
                    if ($count_members['count']) {
                        $player->sendMessage("Member:");
                        while ($members_list = $members->fetchArray()) {
                            $player->sendMessage(TextFormat::DARK_PURPLE . $members_list['Name']);
                        }
                    } else {
                        $player->sendMessage(TextFormat::GRAY . "There are no member");
                    }
                }
                if (!$count['count'] && $subcommand == "members" && !empty($region)) {
                    $player->sendMessage(TextFormat::RED . "The $region does not exist!");
                }
                if ($subcommand == "flags" && $count['count'] && !empty($region)) {
                    $flags       = $this->db->query("SELECT Flag,Value FROM FLAGS WHERE Region = '$region'");
                    $count_flags = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                    $player->sendMessage(TextFormat::DARK_GRAY . "==== " . TextFormat::GRAY . "Flag region $region " . TextFormat::DARK_GRAY . "====");
                    if ($count_flags['count']) {
                        $player->sendMessage(TextFormat::BLUE . "Flag:");
                        while ($flags_list = $flags->fetchArray()) {
                            $player->sendMessage(TextFormat::DARK_PURPLE . $flags_list['Flag'] . ": " . TextFormat::BLUE . $flags_list['Value']);
                        }
                    } else {
                        $player->sendMessage(TextFormat::GRAY . "Flag didnt set");
                    }
                }
                if (!$count['count'] && $subcommand == "flags" && !empty($region)) {
                    $player->sendMessage(TextFormat::RED . "The $region does not exist!");
                }
                if ($region == "info" && empty($subcommand)) {
                    $level        = $player->getLevel()->getName();
                    $x            = $player->getX();
                    $y            = $player->getY();
                    $z            = $player->getZ();
                    $result_check = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
                    $result       = $this->db->query("SELECT * FROM AREAS WHERE (Pos1X <= $x AND $x <= Pos2X) AND (Pos1Y <= $y AND $y <= Pos2Y) AND (Pos1Z <= $z AND $z <= Pos2Z) AND Level = '" . $level . "';")->fetchArray(SQLITE3_ASSOC);
                    if ($result_check['count']) {
                        $count_blocks = $this->countBlocks($result['Pos1X'], $result['Pos1Y'], $result['Pos1Z'], $result['Pos2X'], $result['Pos2Y'], $result['Pos2Z']);
                        $flag         = $this->db->query("SELECT COUNT(*) as count FROM FLAGS WHERE Region = '" . $result['Region'] . "' AND Flag = 'info' AND Value = 'deny'")->fetchArray(SQLITE3_ASSOC);
                        if (!$flag['count'] || $username == $result['Owner'] || $player->isOp()) {
                            $player->sendMessage(TextFormat::DARK_GRAY . "===== Region " . TextFormat::GRAY . $result['Region'] . " " . TextFormat::DARK_GRAY . "=====\n" . TextFormat::BLUE . "Owner: " . TextFormat::YELLOW . $result['Owner'] . "\n" . TextFormat::BLUE . "Blocks Count: " . TextFormat::YELLOW . $count_blocks . "\n" . TextFormat::BLUE . "Pos 1: " . TextFormat::YELLOW . $result['Pos1X'] . " " . $result['Pos1Y'] . " " . $result['Pos1Z'] . "\n" . TextFormat::BLUE . "Pos 2: " . TextFormat::YELLOW . $result['Pos2X'] . " " . $result['Pos2Y'] . " " . $result['Pos2Z']);
                        } else {
                            $player->sendMessage("§6>§f Information about this region is hidden");
                        }
                    } else {
                        $player->sendMessage("§6>§f There are no region here");
                    }
                }
                if ($region == "pos1") {
                    $x                     = round($player->getX());
                    $y                     = round($player->getY());
                    $z                     = round($player->getZ());
                    $level                 = $player->getLevel()->getName();
                    $this->pos1[$username] = array(
                        $x,
                        $y,
                        $z,
                        $level
                    );
                    $player->sendMessage(TextFormat::LIGHT_PURPLE . '§6>§f The first point is set to§c: (' . $x . ', ' . $y . ', ' . $z . ')');
                    if (isset($this->pos1[$username]) && isset($this->pos2[$username]) && $this->pos1[$username][3] == $this->pos2[$username][3]) {
                        $pos1   = $this->pos1[$username];
                        $pos2   = $this->pos2[$username];
                        $min[0] = min($pos1[0], $pos2[0]);
                        $max[0] = max($pos1[0], $pos2[0]);
                        $min[1] = min($pos1[1], $pos2[1]);
                        $max[1] = max($pos1[1], $pos2[1]);
                        $min[2] = min($pos1[2], $pos2[2]);
                        $max[2] = max($pos1[2], $pos2[2]);
                        $count  = $this->countBlocks($min[0], $min[1], $min[2], $max[0], $max[1], $max[2]);
                        $player->sendMessage("§6>§f Selected $count blocks");
                    }
                }
                if ($region == "pos2") {
                    $x                     = round($player->getX());
                    $y                     = round($player->getY());
                    $z                     = round($player->getZ());
                    $level                 = $player->getLevel()->getName();
                    $this->pos2[$username] = array(
                        $x,
                        $y,
                        $z,
                        $level
                    );
                    $player->sendMessage(TextFormat::LIGHT_PURPLE . '§6>§f The second point is set to: (' . $x . ', ' . $y . ', ' . $z . ')');
                    if (isset($this->pos1[$username]) && isset($this->pos2[$username]) && $this->pos1[$username][3] == $this->pos2[$username][3]) {
                        $pos1   = $this->pos1[$username];
                        $pos2   = $this->pos2[$username];
                        $min[0] = min($pos1[0], $pos2[0]);
                        $max[0] = max($pos1[0], $pos2[0]);
                        $min[1] = min($pos1[1], $pos2[1]);
                        $max[1] = max($pos1[1], $pos2[1]);
                        $min[2] = min($pos1[2], $pos2[2]);
                        $max[2] = max($pos1[2], $pos2[2]);
                        $count  = $this->countBlocks($min[0], $min[1], $min[2], $max[0], $max[1], $max[2]);
                        $player->sendMessage("§6>§f Selected $count blocks");
                    }
                }
                if ($region == "help") {
                    $BLUE   = TextFormat::BLUE;
                    $YELLOW = TextFormat::YELLOW;
                    $player->sendMessage("§6>§3 /rg pos1§4 and§3 /rg pos2§4 -§6 set region position§r\n§6>§3 /claim <region name>§4 -§6 create region§r\n§6>§3 /unclaim <region>§4 -§6 delete region§r\n§6>§3 /rg info§4 -§6 information about region§r\n§6>§3 /addmember <region> <name>§4 -§6 add player to the region§r\n§6>§3 /member§4 -§6 member list§r\n§6>§3 /flag <region> <flag> <allow/deny>§4 -§6 Install/set flag for region§r\n§6> §3/removemember <player> §4 -§6 delete player from region");
                }
                break;
            case 'claim':
                $level  = $player->getLevel()->getName();
                $region = \SQLite3::escapeString(strtolower(array_shift($args)));
                $xgroup = $this->xgroup->getAll();
                $xperms = $this->getServer()->getPluginManager()->getPlugin("xPermissions");
                if ($xperms) {
                    $xuser      = $this->getServer()->getPluginManager()->getPlugin("xPermissions")->getUser($sender->getName());
                    $user_group = $xuser->getUserGroup($level)->getName();
                    if (isset($xgroup[$user_group]) && is_array($xgroup[$user_group])) {
                        $group = $user_group;
                    } else {
                        $group = $this->config->get("default_xgroup");
                    }
                } else {
                    $group = $this->config->get("default_xgroup");
                }
                if (!empty($region) && preg_match("/^[a-zA-Z0-9_]+$/", $region)) {
                    $check = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray(SQLITE3_ASSOC);
                    if (!$check['count']) {
                        if (!isset($this->pos1[$username]) or !isset($this->pos2[$username])) {
                            $player->sendMessage(TextFormat::RED . '§6>§f Select region');
                            break;
                        }
                        if ($this->pos1[$username][3] !== $this->pos2[$username][3]) {
                            $player->sendMessage(TextFormat::RED . '§6>§f Selected pos in different regions');
                            break;
                        }
                        $pos1   = $this->pos1[$username];
                        $pos2   = $this->pos2[$username];
                        $min[0] = min($pos1[0], $pos2[0]);
                        $max[0] = max($pos1[0], $pos2[0]);
                        $min[1] = min($pos1[1], $pos2[1]);
                        $max[1] = max($pos1[1], $pos2[1]);
                        $min[2] = min($pos1[2], $pos2[2]);
                        $max[2] = max($pos1[2], $pos2[2]);
                        $count  = $this->countBlocks($min[0], $min[1], $min[2], $max[0], $max[1], $max[2]);
                        $result = $this->db->query("SELECT * FROM AREAS WHERE Pos2X >= $min[0] AND Pos1X <= $max[0] AND Pos2Y >= $min[1] AND Pos1Y <= $max[1] AND Pos2Z >= $min[2] AND Pos1Z <= $max[2] AND Level = '" . $pos1[3] . "';")->fetchArray(SQLITE3_ASSOC);
                        if ($result !== false && !$player->isOp()) {
                            $player->sendMessage("§6>§f This region crosses the region border§c:§3  " . $result['Region'] . ".");
                            break;
                        } elseif (($count > $xgroup[$group]['max_region_count_blocks'] || $count == $xgroup[$group]['max_region_count_blocks']) && !$player->isOp()) {
                            $player->sendMessage("§6>§f The maximum number of blocks allowed§c:§3 " . $xgroup[$group]['max_region_count_blocks'] . ".\n§6>§f you have allocated $count block (s)");
                            break;
                        }
                        $level    = $pos1[3];
                        $rg_count = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Owner = '$username'")->fetchArray();
                        if ($rg_count['count'] < $xgroup[$group]["max_regions_num"] || $player->isOp()) {
                            $this->db->exec("INSERT INTO AREAS (Owner, Pos1X, Pos1Y, Pos1Z, Pos2X, Pos2Y, Pos2Z, Level, Region) VALUES ('$username', $min[0], $min[1], $min[2], $max[0], $max[1], $max[2], '$level', '$region')");
                            unset($this->pos1[$username]);
                            unset($this->pos2[$username]);
                            $player->sendMessage("§6>§f The new region has been successfully created and named as§3 $region");
                        } else {
                            $player->sendMessage("§6>§f You can no longer create region");
                        }
                    } else {
                        $player->sendMessage("§6>§f A region named§c:§3 $region §falready exists");
                    }
                } else {
                    $player->sendMessage("§6>§f Invalid region name \n§6> §f Only letters, numbers, and underscores are allowed");
                }
                break;
            case "unclaim":
                $region   = \SQLite3::escapeString(strtolower(array_shift($args)));
                $rg_count = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Owner = '$username' AND Region = '$region'")->fetchArray();
                if (!empty($region)) {
                    if ($rg_count['count']) {
                        $this->db->exec("DELETE FROM AREAS WHERE Region = '$region'; DELETE FROM MEMBERS WHERE Region = '$region'; DELETE FROM FLAGS WHERE Region = '$region'");
                        $player->sendMessage("§6>§f You have deleted your region");
                    } else {
                        $player->sendMessage("§6>§f Region§3 $region §none");
                    }
                } else {
                    $player->sendMessage("§6>§f Usage§c:§3 /unclaim §7<§fregion§7>");
                }
                break;
            case "removerg":
                if (!$sender->hasPermission("worldguardian.commands.removerg")) {
                    $sender->sendMessage("§cYou do not have permission to use this command.");
                    return true;
                }
                
                $region = $this->db->escapeString(strtolower(array_shift($args)));
                $rg_count = $this->db->query("SELECT COUNT(*) as count FROM AREAS WHERE Region = '$region'")->fetchArray();
                if (!empty($region)) {
                    if ($rg_count['count']) {
                        $this->db->exec("DELETE FROM AREAS WHERE Region = '$region'; DELETE FROM MEMBERS WHERE Region = '$region'; DELETE FROM FLAGS WHERE Region = '$region'");
                        $sender->sendMessage("§6>§f The region §3$region §fhas been deleted.");
                    } else {
                        $sender->sendMessage("§6>§f The region §3$region §fdoes not exist.");
                    }
                } else {
                    $sender->sendMessage("§6>§f Usage§c:§3 /removerg §7<§fregion§7>");
                }
                
                break;
        }
        return true;
    }
    public function loadDB()
    {
        @mkdir($this->getDataFolder());
        $this->db = new \SQLite3($this->getDataFolder() . "regions.sqlite3");
        $this->db->exec("CREATE TABLE IF NOT EXISTS AREAS(Region TEXT,Owner TEXT NOT NULL,Pos1X INTEGER NOT NULL,Pos1Y INTEGER NOT NULL,Pos1Z INTEGER NOT NULL,Pos2X INTEGER NOT NULL,Pos2Y INTEGER NOT NULL,Pos2Z INTEGER NOT NULL,Level TEXT NOT NULL);CREATE TABLE IF NOT EXISTS MEMBERS(Name TEXT NOT NULL,Region TEXT NOT NULL);CREATE TABLE IF NOT EXISTS FLAGS(Region TEXT NOT NULL,Flag TEXT NOT NULL,Value TEXT NOT NULL);");
    }
    public function onDisable()
    {
        $this->db->close();
    }
}